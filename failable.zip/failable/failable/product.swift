//
//  product.swift
//  day9failable
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation
class product {
    let name : String
    init?(name : String){
        if name.isEmpty {
            return nil
        }
        self.name = name
    }
}
