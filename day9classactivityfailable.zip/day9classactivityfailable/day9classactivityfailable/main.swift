//
//  main.swift
//  day9classactivityfailable
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation

print("Hello, World!")
let age1 = licence(firstname : "kamal",lastname :"deep",address :"21 hambert",age :  17,location: "brampton")
if let licence1 = age1{
    print("person informaton \(licence1.firstname)  \(licence1.lastname) \(licence1.address) \( licence1.age ?? 16) \(licence1.location)")
}
else{
    print("age should be more than or equal to 16")
}
