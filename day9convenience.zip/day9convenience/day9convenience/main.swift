//
//  main.swift
//  day9convenience
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation

print("Hello, World!")

var objmanu = manufacturer()
print("\(objmanu.name)")

// no parameter
let noofobject = vehicle()

//one parameter
let alienvehicle = vehicle(name : "BMW");

//both parameter
let bicycle = vehicle(name : "Bmw" , noofwheels : 2);

let preference1 = preference()
 print(preference1.description)
