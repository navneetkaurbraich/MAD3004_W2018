//
//  trafficerrorhandling.swift
//  day10classactivityerror
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

enum trafficerror : Error{
    case overspeeding
    case signalbrake
    case rulebrake
    case ineligible
    case invalidlicence
    
}

struct drivinginformation{
    var speed : Int
    var signalbrake : String
    var passengerinfo : String
    var licencetype : String
    var fine : Int
    var licenceissuedyear : Int
}
