//
//  manufacturer.swift
//  day9convenience
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation
class manufacturer{
    var name : String
    
    // designated initializer
    init(name : String){
        self.name = name
    }
    
    // convenience initializer
    convenience init(){
        self.init(name : "[unknown]")
    }
}
