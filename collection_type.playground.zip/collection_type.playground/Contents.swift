//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var a = [10, 20, 30, 40, 50]
print("a[0] : \(a[0])")
print("a : ",a)
//print array

let j1 = [10,20]
print("j1: ",j1)

//use methods to add values
var b = [Int]();
print("Size of array b: \(b.count)")
b.append(100)
print("b[0] : \(b[0])")

b.append(1000)
print("b : ",b)

b[0]=1000
print("b[0] : \(b[0])")

/* index out of range error
b[2]=500
print("b : ",b)
print("size of array b : \(b.count)")
*/

//assigning the default value
var num1 = [Int] (repeating: 1,count: 3)
print("num1 array : \(num1)")
var num2=[Int] (repeating: 5,count: 3)
print("num2 array : \(num2)")
var nummerge = num1 + num2
print("nummerge array : \(nummerge)")

//declare to store any type values
var c = [Any]();
print("size of array c : \(c.count)")
c.append(100)
c.append("patel")
c.append(100.23)
print( "c array : \(c)")

var x = a[1...3]
for t in x {
    print("x : \(t)")
}

//string array and for-each with (key, value)
var shoppinglist : [String] = ["eggs", "milk"]
for(index, value) in shoppinglist.enumerated() {
    print("item \(index): \(value)")
}

print("The shopping list contains \(shoppinglist.count) items.")

if shoppinglist.isEmpty {
    print("The shopping list is empty")
}
else {
    print("The shopping list is not empty.")
}

shoppinglist.append("flour")
print("shoppinglist array : \(shoppinglist)")

shoppinglist += ["chocolate spread" , "cheese", "butter"]
print("shoppinglist array : \(shoppinglist)")

//shoppinglist[4...6]=["banana","apple"]
shoppinglist.insert("maple syrup", at: 0)
let maplesyrup = shoppinglist.remove(at: 2)
let apples = shoppinglist.removeLast()
print("shoppinglist array : \(shoppinglist)")


//set
//declare set in swift

var grades: Set<Character> = []
grades.insert("A")
grades.insert("B")
grades.insert("C")
print("Grades : \(grades)")
print("grades no of elements",grades.count)

if grades.isEmpty {
    print("The grades are empty")
}
else {
    print("The grades are not empty.")
}

//REQUIRES hashable
//var gradetype:Set <Any> = []

var favoritegenres: Set<String> = ["Rock", "Classical", "Hip Hop"]
print("favoritegenres : \(favoritegenres)")

print("I have \(favoritegenres.count) favorite music genres.")

if favoritegenres.isEmpty {
    print("As far as music goes, I'm not picky.")
}
else {
    print("I never much cared for that")
}

print("favoritegenres : \(favoritegenres)")
for genre in favoritegenres.sorted() {
    print("\(genre)")
}
favoritegenres.insert("Jazz")
print("favoritegenres : \(favoritegenres)")

if let removegenre = favoritegenres.remove("Rock") {
    print("\(removegenre)? I'm over it.")
}
else {
    print("I never much cared for that.")
}

//functions on set
let odddigits : Set = [1,3,5,7,9]
let evendigits : Set = [0,2,4,6,8]
let singledigitprimenumbers : Set = [2,3,5,7]

print(odddigits.union(evendigits).sorted())
print(odddigits.intersection(evendigits).sorted())
print(odddigits.subtracting(singledigitprimenumbers).sorted())
print(odddigits.symmetricDifference(singledigitprimenumbers).sorted())


let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]
print(houseAnimals.isSubset(of: farmAnimals))
print(farmAnimals.isSuperset(of: houseAnimals))
print(farmAnimals.isDisjoint(with: cityAnimals))

