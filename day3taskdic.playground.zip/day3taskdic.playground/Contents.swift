//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var person = [String : AnyObject]()
person["firstname"] = "kamal" as AnyObject
person["lastname"] = "deep" as AnyObject
person["age"] = Int(27) as AnyObject
person["address"] = ["street" : "265 yoekland","area" : "north york","postal code" : "m1hy1y"] as AnyObject

for (k,v) in person {
    print("\(k) -> \(v)")
}
