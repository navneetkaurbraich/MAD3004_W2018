//: Playground - noun: a place where people can play

import UIKit


var a = 20
var b = 3
if (a<20)
{
    for i in 1...5{
        a = 5*1
        print("5","*", i,"=",a)
    }
    else {
        for i in 1...5{
            a *=i
            print("factorial is", a)
        }
    }
}
