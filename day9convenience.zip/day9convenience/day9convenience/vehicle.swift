//
//  vehicle.swift
//  day9convenience
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation

class vehicle : manufacturer{
    var noofwheels : Int
    
    init(name : String , noofwheels : Int){
        self.noofwheels = noofwheels
        super.init(name : name)
    }
    // overirde convenience init(name : String)
    override convenience init(name : String){
        self.init(name : name, noofwheels : 0)
    }
}
