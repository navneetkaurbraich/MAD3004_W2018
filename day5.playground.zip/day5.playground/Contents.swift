//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//classes
class Employee {
    var empid: Int?
    var empname: String?
    var basicpay: Double?
    
    //intializers
    init() {
        self.empid = 0
        self.empname = ""
        self.basicpay = 0
    }
    
    //parametrised initializers
    init(id:Int, nm: String, pay: Double) {
        self.empid = id
        self.empname = nm
        self.basicpay = pay
    }
    func display(){
        print("Employee id : ", self.empid!)
        print("Employee Name: ",self.empname!)
        print("Basic salary: ", self.basicpay!)
        //function display the variablea
    }
        //deinitializer
        deinit{
            print("Employee object deinitiallized")
            }
}

var emp1 = Employee()
emp1.empid = 101
emp1.empname = "Srijith"
emp1.basicpay = 5000
emp1.display()
//created a object of class employee

var emp3 = Employee()
emp3.display()

class permanentEmployee : Employee {
    var  vacationweeks : Int?
    
    //default initializer
    override init(){
        super.init()
        self.vacationweeks = 0
    }
    
    //parametrised initializer of subclass
    init(eid: Int,enam: String, epay: Double, weeks: Int){
        super.init(id: eid, nm: enam, pay:epay)
        self.vacationweeks = weeks
    }
    
    override func display() {
    super.display()
    print("Vacation weeks : ", vacationweeks!)
    }
}
//inheritance class works along with override function and super function

var obj2 = permanentEmployee()
obj2.empid = 102
obj2.empname = "Tuan"
obj2.basicpay = 10000
obj2.vacationweeks = 10
obj2.display()
//call both functions


var emp4 = Employee (id:104, nm: "Navneet", pay:3409.89)
emp4.display()
//object emp4 diplay

var obj5 = permanentEmployee()
obj5.display()
//object obj5 display

var obj6 = permanentEmployee(eid: 106, enam: "Navjot", epay: 1320.77, weeks: 1)
obj6.display()

class payroll : permanentEmployee {
    let  finalpay : Double? {
        get{
            var vw = self.vacationweeks!
            if vw > 5{
                return self.basicpay! - 100
            }
            else{
                return self.basicpay!
        }
    }
    }
    //default initializer
        
    override init(){
        super.init()
        //self.finalpay = 0
    }
    //parametrised initializer of subclass
    init(eid1: Int,enam1: String, epay1: Double, weeks1: Int, finalpay: Double){
        super.init(eid: eid1, enam: enam1, epay: epay1, weeks: weeks1 )
        //self.finalpay = finalpay
    }
    
    override func display() {
        super.display()
        
        print("Final Pay: ", finalpay!)
        
        /*func calculate()
        {
            var vw = self.vacationweeks!
            if vw > 5{
                self.finalpay! = self.basicpay! - 100
         }
         else{
         return self.basicpay!
         }*/
         }
       }


 var emp7 = payroll(eid1: 108, enam1: "Navu", epay1: 1234.98,weeks1: 4, finalpay: 5000 )
emp7.display()


//manipulate object array[]
var janpayroll = [payroll]()
let noofemployees = 2

for i in 0..<2{
    janpayroll.append(payroll(eid1: 107, enam1: "nav", epay1: 5555.78,weeks1: 7))
    janpayroll[i].display()
}


