//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var str1="nil "
print(str1)

var str2 = " "
print(str2)

//dictionaries
var nameofintegers = [Int: String]()
//it is a empty dictionary with datatype int and string

nameofintegers[16] = "sixteen"
//one key value pair
print("nameofintegers : \(nameofintegers.count) elements")
nameofintegers[28] = "Twenty Eight"
print("dictionary contains : \(nameofintegers.count) elements")
print("dictionary : ",nameofintegers)

nameofintegers = [:]
//empty dictionary of type int and string
print("dictionary contains \(nameofintegers.count) elements")
print("nameofintegers : ",nameofintegers)

if nameofintegers.isEmpty {
    print("Dictionary is empty")
}
else {
    print(nameofintegers)
}
//chech whether the dictionary is empty or not

var airports : [String: String] = ["yyz": "Toronto pearson", "dub": "dublin","indra gandhi": "india"]
print("airports : \(airports)")
print("The airports dictionary contains \(airports.count) items.")
//new dictionary is created

airports["lhr"] = "London Heathrow"
//new value is added

airports["yyz"] = "tp international"
airports["amd"] = "svp international"
print("airports : \(airports)")

 let oldvalue = airports.updateValue("dublin airport", forKey: "dub")
print("The old value for dub was \(oldvalue).")
//print old value of dub

if let airportname = airports["amd"] {
 print("The name of the airport is \(airportname)")
}
else {
    print("That airport is not in the airport dictionary")
}
// check the value  with if statement


airports["mars"] = "range rover"
print(airports)
//add new key

airports["mars"] = nil
print(airports)
//make a key nil and it will remove the whole key

if let removedvalue = airports.removeValue(forKey: "dub") {
print("The removed airport's name is \(removedvalue).")
}
else {
    print("The airports dictionary does not contain a value for dub.")
}
//print the removed airport's name

for (airportcode, airportname) in airports {
    print(airportcode, airportname)
}
//print airportcode alongwith airport name

for airportcode in airports.keys {
    print("airport code: \(airportcode)")
}
//show only airport codes

for airportname in airports.values {
    print("Airport name: \(airportname)")
}
//show all airport names

let airportcodes = [String] (airports.keys)
print("airportcodes : \(airportcodes)")
//airport codes

let airportnames = [String] (airports.values)
print("airportnames : \(airportnames)")
//print airport names

//<key,value> pairs
var d1 : Dictionary<String, String> = ["india":"hindi","canada":"english"]
print(d1)
print(d1.description)
print(d1["india"]!)
print(d1["canada"]!)
print(d1["usa"])
d1["china"] = "mandarin"
for (k,v) in d1 {
    print("\(k) -> \(v)")
}

var d2 = ["india" : "hindi", "canada" : "english"]
for (k,v) in d2 {
    print("\(k) -> \(v)")
}


//dictionary with any value type
var d3 = [String : AnyObject]()
d3["firstname"] = "navneet" as AnyObject
d3["lastname"] = "kaur" as AnyObject
d3["age"] =  Int(50) as AnyObject
d3["salary"] = nil
print("d3",d3)

//getting as a key, value pair
for (k,v) in d3 {
    print ("\(k)-> \(v)")
}

//getting a single object
for obj in d3 {
    print("\(obj.key) -> \(obj.value)")
}

//declaring tuples
var x = (10,20,"kaur")
print(x.0)
print(x.1)
print(x.2)

let http404error = (404, "not found")
print(http404error)

let (statuscode, statusmessage) = http404error
print("statuscode:", statuscode)
print("statusmessage:", statusmessage)


let (codeonly,_) = http404error
print("codeonly:", codeonly)

let errordescription = (code: 404, message:"not found")
print(errordescription.code,errordescription.message)

//declaration of function
func add()
{
    print("I am in user defined function")
}

add()

func add(n1:Int,n2:Int){
    var sum :Int
    sum = n1+n2
    print("sum : ",sum)
}
//swift allow two same function name with different declaration

add(n1:10,n2:20)
//label the number

//error add(n2:30,n1:20)

//single parameter
func welcome(name:String)
{
    print("hello, \(name)")
}

welcome(name: "navu")

//making parameter label optional using _
func sub(a:Int, _ b:Int)
{
    let c=a-b
    print("sub : \(c)")
}
sub(a:10,5)

//single return type
func mul(a:Int, b:Int) -> Int {
    let c = a*b
    print("mul : \(c)")
    return c
    
}
mul(a: 3, b: 5)

func swipe(number1 a: Int, b: Int) -> (Int,Int)
{
    //function parameters are constant by default
    //var temp =a
    //a=b
    //b=temp
    return (b,a)
}

var (a,b) = swipe(number1: 10, b: 20)
print("a : \(a), b: \(b)")
var (_,c) = swipe(number1: 10,b:20)
print("c: \(c)")

//inout concept
func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}

var x1 = 8.0, y1 = 9.0
swipe(aa:&x1 , bb: &y1)
print("x : \(x1),y : \(y1)")

//default parameter
func simpleinterest(amount : Double, noofyears: Double, rate: Double = 5.0) -> Double
{
    let si = amount * rate * noofyears / 100
    return si
}

print("simple interest: \(simpleinterest(amount: 1000, noofyears: 5))")
print("simple interest: \(simpleinterest(amount: 1000, noofyears: 5, rate: 10))")

//variadic parameters
func display(n:Int...)
{
    for i in n{
        print(i)
    }
}

display(n: 1,2,3,4,5)
display(n: 10,20,30)


func simpleinterest(amount : Double,_ noofyears: Double, rate: Double = 5.0) -> Double
{
    let si = amount * rate * noofyears / 100
    return si
}

print("simple interest: \(simpleinterest(amount: 1000, noofyears: 5))")
print("simple interest: \(simpleinterest(amount: 1000, noofyears: 5, rate: 10))")

//passing array as parameter
func display(numbervalues: Int, parameters:[Int]...)
{
    print("number of values : \(numbervalues)")
    for i in parameters {
        print("i: \(i)")
    }
}

var arr = [1,2,3,4,5]
display(numbervalues : 3, parameters: arr,arr,arr)

func display(arraylist: [Int]...) -> [Int]
{
    var array1 = arraylist[0]
    var array2 = arraylist[1]
    var result = [Int]()
    
    if array1.count == array2.count {
        for i in 0..<array1.count{
            result.append(array1[i] + array2[i])
            
        }
    }
    return result
    
}

var a1 = [1,2,3,4,5]
var a2 = [10,11,12,13,14]
var a3 = (display(arraylist: a1,a2))
print (a1)
print(a2)
print(a3)





