//
//  main.swift
//  day10classactivityerror
//
//  Created by MacStudent on 2018-02-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var proceesrequest = requesttraffic()
do{
    try proceesrequest.decresedfine(trafficrule: "t120")
}catch trafficerror.overspeeding{
    print("your car is over speeded")
}catch  trafficerror.signalbrake{
    print("you break red signal")
}catch trafficerror.invalidlicence{
    print("your licence is invalid")
}catch trafficerror.rulebrake {
    print("you haven't wore belt")
}
    
catch{
    print("unexpected error")
}
