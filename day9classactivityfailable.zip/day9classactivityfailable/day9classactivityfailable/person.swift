//
//  person.swift
//  day9classactivityfailable
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation
class person{
    var firstname : String
    var lastname : String
    var address : String
    
    init?(firstname : String,lastname : String,address : String){
        if firstname.isEmpty{
            return nil
        }
        self.firstname = firstname
        self.lastname = lastname
        self.address = address
    }
}
