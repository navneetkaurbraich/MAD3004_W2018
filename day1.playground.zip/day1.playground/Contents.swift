//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
//used to replace ending place that is terminator
print("This is our string: \(str)",terminator:" ")

//use seprator for seprating multiple prompts
print("1","2","3","4","5",separator: "..")

//declare and print variables
var n1=10
print ("Number 1: ",n1,"string :",str)

var n2=20
print("Number 2:",n2)

var sum=n1+n2
print("sum is:",sum)
print("sum=",n1+n2)

//n1= "test"
// print("n1:",n1)


var a:Int=10
print("a=",a)

var greet:String="Good Morning"
print("Greetings:",greet)

var emoji = "☺️"
print ("ist a \(emoji) hour")
//use emoji by ctrl+windows+space on windows
//use emoji by ctrl+cmd+space on mac

let pi=3.14
//pi=3.190
print("pi=",pi)

//optional values
let mynumber:Int?
mynumber=10

if mynumber != nil {
    print("mynumber: ",mynumber!)
}
else{
print("mynumber is nil")
}
    let possiblenumber="hello"
    let convertednumber:Int?
    
    convertednumber = Int(possiblenumber)
    
    if convertednumber != nil {
        print("converte number" , convertednumber!)
    }
    else {
        print("converted number is nil")
}
        for i in 1...5{
            print("i = ",i)
}
let languages:[String]
languages=["english", "spanish", "french"]

for i in languages {
    print("language: ",i)
}

//sum of an array
var addition: Int = 1

for _ in 1...5{
    addition *= 5;
}
print("addition= ",addition)

var Interval:Int = 5
for i in stride(from: 0, to: 50, by: Interval){
print(i," ",terminator:" ")
}

var itr1 = 1
while (itr1<5) {
    print("value of itr1 is \(itr1)")
  itr1 = itr1+1
}

var num1 = 100

switch num1 {
case 100 :
        //print("Value of num1 is 100")
    print(" its 100")
case 10,15:
        print("Value of num1 is either 10 or 15")
case 5:
        print("value of num1 is 5")
default:
        print("default case")
}


