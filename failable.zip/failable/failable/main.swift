//
//  main.swift
//  failable
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation

print("Hello, World!")

let laptop = product(name : "laptop")

if let machine = laptop {
    print("product name is \(machine.name)")
}

let anonymousmachine = product(name : "")

if anonymousmachine == nil {
    print("the anonymous machine could not be initialized")
}
if let oneprojector = cartitem(name : "projector" , quantity : 0){
    print("cart contains \(oneprojector.quantity) \(oneprojector.name)")
}
else{
    print("unable to initialize cart item")
}
