//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
//print a string statement
print(str)

let strOne = """
This is first line
This is another line
This is one more line
ok.enough of lines
"""

print(strOne)

let heart="\u{1F496}"
var mood = "happy"
if mood.isEmpty{
    print("cheer up")
}
else{
    print(heart)
}

mood += "cheerful joyful"
print(mood)

//heart +="Be Happy"

var firstname = String()
firstname = "navneet"
print(firstname)

for i in firstname {
    print(i)
}

let initial : Character = "n"
firstname.append(initial)

print(firstname)

print("firstname is \(firstname) which is \(firstname.count) character long. ")


let exclamationMark: Character = "!"
firstname.append(exclamationMark)
//print exclamation at the end by using eppend


print(firstname)

// String literal
var a = "Hello "

// Append something
a += "World!"
print(a)


print("start index:",firstname[firstname.startIndex])
//print("end index:",firstname[firstname.endindex])
print("before end index:", firstname[firstname.index(before: firstname.endIndex)])
print("after start index:", firstname[firstname.index(after: firstname.startIndex)])
print("5th character:", firstname[firstname.index(firstname.startIndex,offsetBy: 4)])
//print 5th character from string
print("3rd from last character:",firstname[firstname.index(firstname.endIndex,offsetBy: -3)])
//print last 3rd character from  string

var idx = firstname.index(firstname.startIndex,offsetBy: 3)
print("fourth character:",firstname[idx])
//print character within variable


var name = String()
name = "navneet"
print(name)
print("name is \(name) which is \(name.count) character long. ")
for i in 1...7 {
    print("before end index:",name[name.index(before: name.endIndex)])
}

var language="swift"
print ("language:",language)
//variable language to print

language.insert("!",at:language.endIndex)
print("language :",language)
//print ! exclamatory by using insert operation

language.insert(contentsOf: "java", at: language.endIndex)
print("language: ",language)
//print new word at the end by using insert

language.insert(contentsOf: "is nice than", at: language.index(language.startIndex,offsetBy: 6))
print("language contentof: ",language)
//add another words at 5th location

let greeting = "happy holidays!"
let index = greeting.index(of: " ") ?? greeting.endIndex
let start=greeting[..<index]
let newgreet = String(start)

print("sub string:",newgreet)
print("string in uppercase: ",newgreet.uppercased())
// use uppercase function

if(newgreet == newgreet.uppercased()){
    print("Equal")
}
else {
    print("Not equal")
}
//uppercased with if





