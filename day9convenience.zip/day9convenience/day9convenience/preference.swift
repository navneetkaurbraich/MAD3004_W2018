//
//  preference.swift
//  day9convenience
//
//  Created by master on 2018-02-08.
//  Copyright © 2018 master. All rights reserved.
//

import Foundation

class preference : vehicle{
    var prefer = true
    var description : String{
        var output = "do you prefer \(noofwheels) wheel vehicle from \(name) ?"
      output += prefer ? " ✔" : " ✘"
       return output
    }
}
